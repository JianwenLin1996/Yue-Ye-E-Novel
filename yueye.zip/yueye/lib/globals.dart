library yueye.globals;

int bookmark = 1;
